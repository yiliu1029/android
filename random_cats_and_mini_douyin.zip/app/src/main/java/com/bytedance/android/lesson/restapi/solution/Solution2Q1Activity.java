package com.bytedance.android.lesson.restapi.solution;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Solution2Q1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solution2_q1);


    }
}
